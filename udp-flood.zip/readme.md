# Multi-Flood Tool

## Introduction

`multi_flood` is a powerful and flexible experimental tool designed to simulate Denial of Service (DoS) attacks at the network and transport layers. This tool allows users to send various types of flood packets (UDP, ICMP, ICMP Fragmentation, TCP SYN/ACK/FIN/RST) with different source IP spoofing modes (random, reflective, loopback) to a target host.

The primary objective of this project is to research and gain a deeper understanding of how flood attacks operate at the kernel/operating system level, as well as the defensive capabilities of modern systems.

**Disclaimer:** This tool is intended solely for research, educational, and experimental purposes within a controlled and isolated environment. Using this tool to attack any system without explicit authorization is illegal and unethical. The developer assumes no responsibility for any misuse.

## Principles of Operation

`multi_flood` operates by crafting custom IP packets (using raw sockets) and sending them to the target. It leverages multithreading to enhance the attack intensity. Key principles include:

*   **Raw Sockets:** Allows the program to manually construct entire IP headers and transport layer headers (UDP, ICMP, TCP), including the ability to spoof source IP addresses.
*   **Multithreading:** Multiple threads operate in parallel to create and send packets, increasing the rate and pressure on the target.
*   **Source IP Spoofing Modes:**
    *   **Spoofed Random:** Uses random source IP addresses to complicate tracing and redirect responses.
    *   **Reflective Attack:** Spoofs the source IP address as the destination IP address. This forces the target to send response packets back to itself, overwhelming its internal bandwidth.
    *   **Loopback Flood:** Spoofs the source IP address as `127.0.0.1`. This forces the target to process response packets through its own loopback interface, potentially over-consuming CPU and internal network resources.
    *   **Router Loopback Flood:** Spoofs the source IP address as the IP address of the Default Gateway (Router). This forces the Router to process response packets destined for itself, potentially overwhelming the Router's resources.
*   **Flood Types:**
    *   **UDP Flood:** Sends a large volume of UDP packets. Can overwhelm UDP services or trigger ICMP unreachable responses (if no listener and no ICMP rate limiting).
    *   **ICMP Plain Flood:** Sends a large volume of ICMP Echo Request packets (similar to `ping`). Forces the target to generate responses, consuming CPU.
    *   **ICMP Fragmentation Flood:** Sends incomplete IP packet fragments (typically only the first fragment) with the "More Fragments" flag set. Forces the target kernel to allocate memory and CPU resources to attempt reassembly of incomplete packets, which never arrive fully. This is often an effective way to consume kernel CPU without requiring an open application port.
    *   **TCP SYN Flood:** Sends a large volume of TCP SYN packets to initiate connections. Overfills the target's "SYN queue", preventing legitimate connections.
    *   **TCP ACK Flood:** Sends a large volume of TCP ACK packets without a valid established connection. Forces the kernel to check its connection state table.
    *   **TCP FIN/RST Flood:** Sends a large volume of TCP FIN/RST packets. Forces the kernel to check its connection state table and attempt to tear down non-existent connections.
*   **Resource Optimization:** The program is designed to allocate memory for the packet once and only update dynamic fields within the main loop, minimizing overhead on the attacking machine.

## System Requirements

*   Linux-based operating system (e.g., ParrotOS, Ubuntu).
*   GCC compiler.
*   `pthread` library.
*   `root` privileges to run the program (due to the use of raw sockets).

## Project Structure

```
multi_flood_project/
├── build/                 # Contains compiled object files (.o) and the executable
├── include/               # Contains all header files (.h)
│   ├── common.h           # General definitions, macros, global variables
│   └── flood_logic.h      # Declarations for sender_thread and checksum functions
│   └── utils.h            # General utility function declarations
└── src/                   # Contains all source files (.c)
    ├── main.c             # Main function, command-line argument parsing, thread initialization
    └── flood_logic.c      # Core logic for constructing and sending packets for all flood types
    └── utils.c            # Implementations of utility functions
└── Makefile               # Makefile for building the project
```

## Usage Guide

### 1. Environment Setup

*   **Clone Repository:**
    ```bash
    git clone [Your Repository URL]
    cd multi_flood_project
    ```
*   **Target Machine Configuration (Windows VM):**
    *   **Network Connection:** Ensure your Windows VM is connected to your Linux host (ParrotOS) via a **Host-Only Adapter**.
    *   **Disable Windows Firewall:**
        ```cmd
        netsh advfirewall set allprofiles state off
        ```
    *   **Disable Windows Defender (Real-time protection):** From the Windows Security interface.
    *   **Adjust TCP/IP Registry Settings (for TCP/SYN Flood):**
        ```cmd
        reg add HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v SynAttackProtect /t REG_DWORD /d 0 /f
        reg add HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v TcpMaxHalfOpen /t REG_DWORD /d 65535 /f
        reg add HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v TcpMaxHalfOpenRetried /t REG_DWORD /d 65535 /f
        ```
    *   **Restart the Windows VM** after applying the firewall and Defender changes.
    *   **Run Target Services (if applicable):** For example, `python -m http.server 8000` for an HTTP server, or ensure the SSH server is running on port 22.
    *   **Open Task Manager/Resource Monitor** on the target machine to observe CPU, Memory, and Network usage.

### 2. Building the Program

Open a terminal in the root directory of your project (`multi_flood_project/`) and run:

```bash
make
```
The executable will be created in the `build/` directory as `multi_flood`.

### 3. Running the Program

The program requires `root` privileges to run.

**General Syntax:**
```bash
sudo ./build/multi_flood -d <destination IP> -T <flood_type> [OPTIONS]
```

**Options:**

*   `-d <destination IP>`: Target IP address. (REQUIRED)
*   `-T <flood_type>`: Type of flood attack. (REQUIRED)
    *   `u`: UDP Flood
    *   `i`: ICMP Plain Flood
    *   `f`: ICMP Fragmentation Flood
    *   `s`: TCP SYN Flood
    *   `a`: TCP ACK Flood
    *   `r`: TCP FIN/RST Flood
*   `-P <destination port>`: Target port for TCP/UDP floods (e.g., 80, 22). (REQUIRED for UDP and TCP floods)
*   `-m <mtu>`: MTU of the sending interface (default: 1500).
*   `-n <num_threads>`: Number of threads to use (default: 1, max 100).
*   `-a <attack_mode>`: IP source attack mode. (default: `0`)
    *   `0`: Spoofed Random IP
    *   `1`: Reflective Attack (spoof source IP as destination IP)
    *   `2`: Loopback Flood (spoof source IP as `127.0.0.1`)
    *   `3`: Router Loopback Flood (spoof source IP as the Router's IP)
*   `-l <payload_len>`: Total payload length.
    *   For ICMP Fragmentation Flood (`-T f`): This is the theoretical total ICMP payload length (must be large enough to force fragmentation).
    *   For other flood types: This is the actual payload length (default 0).
*   `-h`: Display this usage guide.

**Examples:**

1.  **UDP Flood (Spoofed Random IP) to `192.168.56.101` on port `8888` with 14 threads, 100 bytes payload:**
    ```bash
    sudo ./build/multi_flood -d 192.168.56.101 -T u -P 8888 -n 14 -l 100
    ```

2.  **ICMP Fragmentation Flood (Reflective Attack) to `192.168.56.101` with 14 threads, theoretical total ICMP payload of 2000 bytes:**
    ```bash
    sudo ./build/multi_flood -d 192.168.56.101 -T f -a 1 -l 2000 -n 14
    ```

3.  **TCP SYN Flood (Router Loopback Flood) to `192.168.56.101` on port `80` with 14 threads:**
    ```bash
    sudo ./build/multi_flood -d 192.168.56.101 -T s -P 80 -a 3 -n 14
    ```

4.  **TCP ACK Flood (Spoofed Random IP) to `192.168.56.101` on port `22` (SSH) with 14 threads:**
    ```bash
    sudo ./build/multi_flood -d 192.168.56.101 -T a -P 22 -n 14
    ```

**To stop the attack, press `Ctrl+C` in the terminal where the program is running.**

## Cleanup

To remove compiled object files and the executable:

```bash
make clean
```
